/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Team]
      ,[Amount]
  FROM [IdkName].[dbo].[TeamTable]