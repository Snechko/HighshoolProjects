/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Username]
      ,[Password]
  FROM [IdkName].[dbo].[LogInTable]