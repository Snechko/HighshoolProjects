﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for TeamsSheet.xaml
    /// </summary>
    public partial class TeamsSheet : Window
    {
        public TeamsSheet()
        {
            InitializeComponent();
            Table();
        }


        private void Table()
        {
            String dbConnection = @"Data Source=LABSCIFIPC18\LOCALHOST; Initial Catalog=IdkName; Integrated Security=True";
            SqlConnection sqlCon = new SqlConnection(dbConnection);
            try
            {
                sqlCon.Open();
                String query = "Select* from TeamTable";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.ExecuteNonQuery();
                SqlDataAdapter adapt = new SqlDataAdapter(sqlCmd);
                DataTable dt = new DataTable("Teamtable");
                adapt.Fill(dt);
                DataGrid1.ItemsSource = dt.DefaultView;
                adapt.Update(dt);

                MessageBox.Show("Here is Table");
                sqlCon.Close();
            }
            catch (Exception)
            {

                MessageBox.Show("Problems");
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FavTeam dashboard = new FavTeam();
            dashboard.Show();
            this.Close();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
