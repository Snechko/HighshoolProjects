﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for FavTeam.xaml
    /// </summary>
    public partial class FavTeam : Window
    {
        bool test = false;
        public FavTeam()
        {
            InitializeComponent();
        }
        String dbConnection = @"Data Source=LABSCIFIPC18\LOCALHOST; Initial Catalog=IdkName; Integrated Security=True";
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(dbConnection);
            //Open coneciton to database
            string team = FavTeamBox.Text;

            SqlCommand cmd = new SqlCommand("Select Team from TeamTable where Team= @Team", sqlCon);
            cmd.Parameters.AddWithValue("@Team", this.FavTeamBox.Text);
            sqlCon.Open();

            var nId = cmd.ExecuteScalar();

            if (nId != null)
            {
                try
                {
                    int amount = 1;
                    String query2 = "Select Amount From TeamTable WHERE Team='" + team + "' ";
                    SqlCommand cmd2 = new SqlCommand(query2, sqlCon);

                    amount = int.Parse(cmd2.ExecuteScalar().ToString());
               
                    amount++;
                    String query = "Update TeamTable set Amount='" + amount + "' where Team='" + team + "' ";
                 
                    SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully saved!");





                    test = true;
                    sqlCon.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }

            }
            else
            {
                try
                {

                    String query = "INSERT INTO TeamTable(Team, Amount) values('" + this.FavTeamBox.Text + "','" + 1 + "')";
                    SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully saved!");
                    sqlCon.Close();
                    test = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }
            }
        }

        private void Button_Clickssss(object sender, RoutedEventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(dbConnection);
            //Open coneciton to database
            try
            {
                sqlCon.Open();
                if (test)
                {
                    int amount = 1;
                    String query2 = "Select Amount From TeamTable WHERE Team='" + this.FavTeamBox.Text + "' ";
                    SqlCommand cmd2 = new SqlCommand(query2, sqlCon);

                    amount = int.Parse(cmd2.ExecuteScalar().ToString());
                    if (amount > 1)
                    {
                        amount--;
                        String query = "Update TeamTable set Amount='" + amount + "' where Team='" + this.FavTeamBox.Text + "' ";

                        SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                        sqlCmd.ExecuteNonQuery();
                        MessageBox.Show("Successfully deleted!");
                        test = false;
                    }
                    else if (amount == 1)
                    {
                        String query = "DELETE from TeamTable where Team = '" + this.FavTeamBox.Text + "' ";
                        SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                        sqlCmd.ExecuteNonQuery();
                        MessageBox.Show("Successfully deleted!");
                        test = false;

                    }

                }
               
                sqlCon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }

        }

        private void Button_Clicki(object sender, RoutedEventArgs e)
        {
            TeamsSheet dashboard = new TeamsSheet();
            dashboard.Show();
            this.Close();
        }
    }
}


